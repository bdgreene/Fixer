﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using Newtonsoft.Json;
using System.IO;


namespace FixersSDK
{
    public sealed class Fixer
    {
        private const string BaseUri = "http://api.fixer.io/";
        static IList<string> currencyNames = new List<string>();
        static IList<ConvertedRates> convertedRates = new List<ConvertedRates>();

        public static string Convert(string baseCurrency, float currencyAmount, string newCurrency)
        {
            using (var client = new HttpClient(new HttpClientHandler { AutomaticDecompression = DecompressionMethods.GZip | DecompressionMethods.Deflate }))
            {
                client.BaseAddress = new Uri("http://api.fixer.io/");
                HttpResponseMessage response = client.GetAsync("latest?base=" + baseCurrency + "&symbols=" + newCurrency).Result;
                if (!response.IsSuccessStatusCode)
                {
                    return "Try Again";
                }
                string result = response.Content.ReadAsStringAsync().Result;

                JsonTextReader reader = new JsonTextReader(new StringReader(result));

                while (reader.Read())
                {
                    if (reader.Value != null)
                    {
                        if (reader.TokenType.ToString() == "Float")
                        {
                            float conversionRate = float.Parse(reader.Value.ToString());
                            currencyAmount = currencyAmount * conversionRate;
                            Console.WriteLine(currencyAmount);

                            ConvertedRates convertedRate = new ConvertedRates();
                            convertedRate.previousCurrency = baseCurrency;
                            convertedRate.newCurrency = newCurrency;
                            convertedRate.ConvertedAmount = currencyAmount;
                            convertedRates.Add(convertedRate);
                        }
                    }
                }
                return currencyAmount.ToString();
            }
        }

        public static IList<string> GetAllCurriences()
        {
            if (currencyNames.Count > 0)
            {
                for (int i = 0; i < currencyNames.Count; i++)
                {
                    Console.WriteLine(currencyNames[i]);
                }
                return currencyNames;
            }

            using (var client = new HttpClient(new HttpClientHandler { AutomaticDecompression = DecompressionMethods.GZip | DecompressionMethods.Deflate }))
            {
                client.BaseAddress = new Uri("http://api.fixer.io/");
                HttpResponseMessage response = client.GetAsync("latest?").Result;
                response.EnsureSuccessStatusCode();

                string result = response.Content.ReadAsStringAsync().Result;

                JsonTextReader reader = new JsonTextReader(new StringReader(result));

                while (reader.Read())
                {
                    if (reader.Value != null && reader.Value.ToString().All(c => char.IsUpper(c)))
                    {
                        Console.WriteLine(reader.Value);
                        currencyNames.Add(reader.Value.ToString());
                    }
                }
            }
            return currencyNames;
        }

        public static void RemovePreviousConversion(int index)
        {
            if (convertedRates.Count == 0)
            {
                return;
            }

            index--;
            for (int i = convertedRates.Count - 1; i > -1; i--)
            {
                if (i == index)
                {
                    convertedRates.RemoveAt(i);
                }
            }
        }
    }
}
