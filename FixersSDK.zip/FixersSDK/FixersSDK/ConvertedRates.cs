﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FixersSDK
{
    class ConvertedRates
    {
        public string previousCurrency;
        public string newCurrency;
        public float ConvertedAmount;
    }
}
